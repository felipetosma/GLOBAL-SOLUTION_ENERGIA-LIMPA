package com.example.energyx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyxApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyxApplication.class, args);
	}

}
