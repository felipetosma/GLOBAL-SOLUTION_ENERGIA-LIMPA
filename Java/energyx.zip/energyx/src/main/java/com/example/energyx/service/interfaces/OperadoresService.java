package com.example.energyx.service.interfaces;

import com.example.energyx.dto.OperadoresDTO;
import java.util.List;

public interface OperadoresService {

    OperadoresDTO cadastrarOperador(OperadoresDTO operadoresDTO);
    OperadoresDTO obterOperadorPorId(Long id);
    List<OperadoresDTO> listarOperadores();
    OperadoresDTO atualizarOperador(Long id, OperadoresDTO operadoresDTO);
    boolean excluirOperador(Long id);
}
