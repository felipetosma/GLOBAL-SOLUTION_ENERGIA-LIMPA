package com.example.energyx.controller;

import com.example.energyx.dto.OperadoresDTO;
import com.example.energyx.service.interfaces.OperadoresService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/operadores")
public class OperadoresController {

    @Autowired
    private OperadoresService operadoresService;

    // Endpoint para cadastrar um novo operador
    @PostMapping("/api/cadastro")
    public ResponseEntity<OperadoresDTO> cadastrarOperador(@Valid @RequestBody OperadoresDTO operadoresDTO) {
        OperadoresDTO operadorCadastrado = operadoresService.cadastrarOperador(operadoresDTO);
        adicionarLinks(operadorCadastrado);
        return new ResponseEntity<>(operadorCadastrado, HttpStatus.CREATED);
    }

    // Endpoint para listar todos os operadores
    @GetMapping
    public ResponseEntity<List<OperadoresDTO>> listarOperadores() {
        List<OperadoresDTO> operadoresList = operadoresService.listarOperadores();
        List<OperadoresDTO> operadoresComLinks = operadoresList.stream()
                .peek(this::adicionarLinks)
                .collect(Collectors.toList());
        return ResponseEntity.ok(operadoresComLinks);
    }

    // Endpoint para obter um operador por ID
    @GetMapping("/{id}")
    public ResponseEntity<OperadoresDTO> obterOperadorPorId(@PathVariable Long id) {
        OperadoresDTO operadorDTO = operadoresService.obterOperadorPorId(id);
        adicionarLinks(operadorDTO);
        return ResponseEntity.ok(operadorDTO);
    }

    // Endpoint para atualizar um operador
    @PutMapping("/{id}")
    public ResponseEntity<OperadoresDTO> atualizarOperador(@PathVariable Long id, @Valid @RequestBody OperadoresDTO operadoresDTO) {
        OperadoresDTO operadorAtualizado = operadoresService.atualizarOperador(id, operadoresDTO);
        adicionarLinks(operadorAtualizado);
        return ResponseEntity.ok(operadorAtualizado);
    }

    // Endpoint para excluir um operador
    @DeleteMapping("/{id}")
    public ResponseEntity<String> excluirOperador(@PathVariable Long id) {
        boolean excluido = operadoresService.excluirOperador(id);
        if (excluido) {
            return ResponseEntity.ok("Operador excluído com sucesso");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Operador não encontrado");
    }

    // Método para adicionar links HATEOAS ao DTO
    private void adicionarLinks(OperadoresDTO operadoresDTO) {
        operadoresDTO.add(linkTo(methodOn(OperadoresController.class).obterOperadorPorId(operadoresDTO.getOperadorId())).withSelfRel());
        operadoresDTO.add(linkTo(methodOn(OperadoresController.class).listarOperadores()).withRel("operadores"));
    }
}
